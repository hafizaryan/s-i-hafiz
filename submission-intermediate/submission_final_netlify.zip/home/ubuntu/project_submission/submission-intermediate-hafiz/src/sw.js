const CACHE_NAME = 'jelajah-nusantara-cache-v1';
const urlsToCache = [
  '/',
  '/index.html',
  '/images/logo.png',
  // Add other static assets that need to be cached
  // CSS files, JS bundles, other images, etc.
];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then((cache) => {
        console.log('Opened cache');
        return cache.addAll(urlsToCache);
      })
  );
});

self.addEventListener('fetch', (event) => {
  event.respondWith(
    caches.match(event.request)
      .then((response) => {
        if (response) {
          return response;
        }
        return fetch(event.request).then(
          (networkResponse) => {
            // Optional: Cache new requests dynamically
            // if (networkResponse && networkResponse.status === 200 && event.request.method === 'GET') {
            //   const responseToCache = networkResponse.clone();
            //   caches.open(CACHE_NAME)
            //     .then(cache => {
            //       cache.put(event.request, responseToCache);
            //     });
            // }
            return networkResponse;
          }
        );
      })
      .catch(() => {
        // Fallback for offline, e.g., return a custom offline page
        // if (event.request.mode === 'navigate') {
        //   return caches.match('/offline.html');
        // }
      })
  );
});

self.addEventListener('activate', (event) => {
  const cacheWhitelist = [CACHE_NAME];
  event.waitUntil(
    caches.keys().then((cacheNames) => {
      return Promise.all(
        cacheNames.map((cacheName) => {
          if (cacheWhitelist.indexOf(cacheName) === -1) {
            return caches.delete(cacheName);
          }
        })
      );
    })
  );
});

// Push Notification Logic
self.addEventListener('push', function (event) {
  const body = event.data ? event.data.text() : 'Default push message';
  event.waitUntil(
    self.registration.showNotification('Jelajah Nusantara', {
      body: body,
      icon: 'images/logo.png'
    })
  );
});

// VAPID Public Key
const VAPID_PUBLIC_KEY = 'BCCs2eonMI-6H2ctvFaWg-UYdDv387Vno_bzUzALpB442r2lCnsHmtrx8biyPi_E-'; // Obtained from previous search

function urlBase64ToUint8Array(base64String) {
  const padding = '='.repeat((4 - base64String.length % 4) % 4);
  const base64 = (base64String + padding)
    .replace(/\-/g, '+')
    .replace(/_/g, '/');

  const rawData = self.atob(base64);
  const outputArray = new Uint8Array(rawData.length);

  for (let i = 0; i < rawData.length; ++i) {
    outputArray[i] = rawData.charCodeAt(i);
  }
  return outputArray;
}

self.addEventListener('message', (event) => {
  if (event.data && event.data.type === 'REGISTER_PUSH') {
    self.registration.pushManager.subscribe({
      userVisibleOnly: true,
      applicationServerKey: urlBase64ToUint8Array(VAPID_PUBLIC_KEY)
    })
    .then(subscription => {
      console.log('Push subscription successful:', subscription);
      // Send the subscription to your server here if needed
      // fetch('/api/subscribe', { method: 'POST', body: JSON.stringify(subscription), headers: { 'Content-Type': 'application/json' } });
    })
    .catch(err => console.error('Push subscription failed:', err));
  }
});
